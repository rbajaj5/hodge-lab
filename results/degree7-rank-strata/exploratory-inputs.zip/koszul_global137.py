import sys,json
from pathlib import Path
W=Path(__file__).parent;R=W.parent/'outputs/hodge-lab';sys.path.insert(0,str(R/'algebra'))
import degree7_rank_strata as rank
s=rank.s;c=rank.c
packet=rank.rb.read(W/'koszul-analyzed137-11.json.gz')
assert all(not st['changes'] for st in packet['continuation']['denominator_chart']['stages'])
global_packet=json.loads((rank.OUT/'global-linear-identities.json').read_text())[1]
model=s.triples.Model();rank.check_global(model,global_packet)
desc,rows=s.shared.construct(model,s.shared.read_packet()['families'][136])
change=rank.zero_map(c.decode(global_packet['linear']),18)
rows=[c.substitute(v,change) for v in rows]
out={'family':137,'system':desc,'linear_dependency':global_packet['linear'],'changes':rank.rb.encode_maps(change),'claims':[]}
for claim in packet['continuation']['power_stages'][0]['claims']:
 combined={}
 for index,mon,q in claim['products']:
  for j,m,v in packet['relations'][index]['products']:
   key=(j,tuple(sorted(m+mon)));combined[key]=combined.get(key,0)+s.triples.Q(q)*s.triples.Q(v)
 combined={key:q for key,q in combined.items() if q};assert max(len(m) for j,m in combined)==1
 lifted={}
 for (j,m),q in combined.items():
  key=(j,tuple(sorted(m+(11,)*(1-len(m)))));lifted[key]=lifted.get(key,0)+q
 actual={}
 for (j,m),q in lifted.items():actual=s.triples.base.padd(actual,c.product(rows[j],{m:q}))
 assert actual=={(claim['coordinate'],)*3:s.triples.Q(1)}
 out['claims'].append({'coordinate':claim['coordinate'],'power':3,'products':[[j,list(m),str(q)] for (j,m),q in sorted(lifted.items()) if q]})
(rank.OUT/'family137-global-cubes.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print('global137',[(x['coordinate'],len(x['products'])) for x in out['claims']],flush=True)
