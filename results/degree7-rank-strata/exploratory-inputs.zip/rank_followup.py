import sys,json,time,subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
W=Path(__file__).parent;R=W.parent/'outputs/hodge-lab';sys.path.insert(0,str(R/'algebra'))
import degree7_rank_strata as rank
import syzygy_accelerated as fast
s=rank.s;c=rank.c;OUT=R/'results/degree7-rank-strata'
def worker(n,p):
 start=time.perf_counter();packet=rank.rb.read(OUT/f'chart-{n}-{p}.json.gz')
 desc,rows,_=rank.seed(s.triples.Model(),n,p);nv=274;node=packet['tree']
 while True:
  proof=node.get('affine_chart')
  if proof:
   c.verify_chart(rows,nv,proof);rows=[c.substitute(v,s.chart_maps(nv,p,proof)) for v in rows]
  if node['status']!='split':break
  assert len(node['children'])==1
  change=rank.zero_map(c.decode(node['claim']['factors'][0]['linear']),18)
  rows=[c.substitute(v,change) for v in rows];node=node['children'][0]
 variables=sorted({i for row in rows for m in row for i in m if i<18})
 mons=[()]+[(i,) for i in variables]
 output=W/f'rank-follow-{n}-{p}.json.gz'
 def checkpoint(relations,rr,count):
  data={'family':n,'pivot':p,'system':desc,'variables':variables,'relations':relations,
        'expanded_rank':rr,'multipliers_processed':count,'complete_multiplier_space':count==len(mons),
        'rows':[c.encode(v) for v in rows],'seconds':time.perf_counter()-start}
  s.shared.save(output,data);return data
 rel,rr=fast.eliminate(rows,18,mons,checkpoint=checkpoint)
 data=checkpoint(rel,rr,len(mons))
 data['baseline'],_=fast.eliminate(rows,18,[()],progress=False)
 _,data['selected_new'],_=s.select_new(data['baseline'],rel,variables)
 c.reduce_span=fast.reduce_span
 proof=c.prove_chart([c.decode(v['polynomial']) for v in data['baseline']]+[c.decode(rel[j]['polynomial']) for j in data['selected_new']],18,p)
 if proof['excluded']:
  data['denominator_contradiction']=proof
 else:
  data['continuation']=s.continue_search(rows,data,max_degree=4)
  s.verify_continuation(rows,data)
 s.shared.save(output,data)
 print('finished',n,p,'new',len(data['selected_new']),'excluded',proof['excluded'] or data.get('continuation',{}).get('excluded',False),flush=True)
def run(case):
 n,p=case;start=time.perf_counter();log=W/f'rank-follow-{n}-{p}.log'
 with log.open('w',encoding='utf-8') as f:
  try:
   r=subprocess.run([sys.executable,__file__,'worker',str(n),str(p)],stdout=f,stderr=subprocess.STDOUT,timeout=120)
   status='completed' if r.returncode==0 else 'error';code=r.returncode
  except subprocess.TimeoutExpired:status='timeout';code=None
 out={'family':n,'pivot':p,'status':status,'returncode':code,'seconds':time.perf_counter()-start,'timeout_seconds':120,'log':log.read_text()}
 print(n,p,status,flush=True);return out
if len(sys.argv)>1:worker(int(sys.argv[2]),int(sys.argv[3]))
else:
 with ThreadPoolExecutor(max_workers=2) as pool:out=list(pool.map(run,[(16,11),(137,8),(16,13),(137,11)]))
 (OUT/'followup-attempts.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
