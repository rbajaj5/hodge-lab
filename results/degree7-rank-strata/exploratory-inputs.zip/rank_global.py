import sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]/'outputs/hodge-lab';sys.path.insert(0,str(R/'algebra'))
import degree7_rank_strata as r
packets=[]
for n,p in [(16,13),(137,11)]:
 chart=r.rb.read(r.OUT/f'chart-{n}-{p}.json.gz');cl=chart['tree']['claim']
 j,k=cl['rows'];assert len(cl['factors'])==1
 packet={'family':n,'system':chart['system'],'linear':cl['factors'][0]['linear'],
         'block':{'rows':[j,k],'correction_coordinate':cl['column']},
         'square_identity':[[j,'9/2'],[k,'-27']]}
 print(r.check_global(r.s.triples.Model(),packet),flush=True)
 packets.append(packet)
(r.OUT/'global-linear-identities.json').write_text(json.dumps(packets,indent=2)+'\n',encoding='utf-8')
