import sys,json,time
from pathlib import Path
from collections import Counter
from flint import fmpq_mat,fmpq
W=Path(__file__).parent;R=W.parent/'outputs/hodge-lab';sys.path.insert(0,str(R/'algebra'))
import degree7_syzygies as s
import degree7_syzygy_rebuild as rb
c=s.cert
for family,pivot in [(16,13),(137,11)]:
 p=rb.read(W/f'rank-seed-{family}-{pivot}.json.gz');nd=len(p['system']['basis_indices']);nk=len(p['system']['Koszul_indices'])
 rows=[c.decode(r) for r in p['rows']]
 active=sorted({i for row in rows for mon in row for i in mon if i<nd})
 result=[]
 for label,values in [('onehot',{i:0 for i in active}),('allone',{i:1 for i in active}),('ramp',{i:i+2 for i in active})]:
  start=time.perf_counter();mat=[]
  for row in rows:
   v=[fmpq(0) for _ in range(nk+1)]
   for mon,q in row.items():
    z=[i for i in mon if i>=nd];col=z[0]-nd if z else nk
    factor=fmpq(q.numerator,q.denominator)
    for i in mon:
     if i<nd:factor*=values[i]
    v[col]+=factor
   mat.append(v)
  rank=fmpq_mat([r[:-1] for r in mat]).rank();aug=fmpq_mat(mat).rank()
  result.append({'sample':label,'rank':rank,'augmented_rank':aug,'seconds':time.perf_counter()-start})
 print(family,result,flush=True)
 (W/f'rank-samples-{family}.json').write_text(json.dumps(result,indent=2))
