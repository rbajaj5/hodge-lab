import sys,time
from pathlib import Path
W=Path(__file__).parent;R=W.parent/'outputs/hodge-lab';sys.path.insert(0,str(R/'algebra'))
import degree7_rank_strata as rank
import syzygy_accelerated as fast
s=rank.s;c=rank.c
p=int(sys.argv[1]);start=time.perf_counter()
packet=rank.rb.read(W/f'rank-follow-137-{p}.json.gz')
rows=[c.decode(v) for v in packet['rows']]
packet['baseline']=[];packet['selected_new']=list(range(len(packet['relations'])))
c.reduce_span=fast.reduce_span
proof=c.prove_chart([c.decode(v['polynomial']) for v in packet['relations']],18,p)
if proof['excluded']:packet['denominator_contradiction']=proof
else:
 packet['continuation']=s.continue_search(rows,packet,max_degree=3)
 s.verify_continuation(rows,packet)
s.shared.save(W/f'koszul-analyzed137-{p}.json.gz',packet)
print('result',p,'excluded',proof['excluded'] or packet.get('continuation',{}).get('excluded'),
 [(st['degree'],[(v.get('coordinate'),v.get('power')) for v in st['claims']]) for st in packet.get('continuation',{}).get('power_stages',[])],
 'seconds',time.perf_counter()-start,flush=True)
