import sys,json
from pathlib import Path
W=Path(__file__).parent;R=W.parent/'outputs/hodge-lab';sys.path.insert(0,str(R/'algebra'))
import degree7_rank_strata as rank
import syzygy_accelerated as fast
s=rank.s;c=rank.c
family,pivot=map(int,sys.argv[1:3]);p=rank.rb.read(W/f'rank-tree2-{family}-{pivot}.json.gz')
desc,rows,_=rank.seed(s.triples.Model(),family,pivot);nv=274;node=p['tree'];maps={}
while True:
 proof=node['affine_chart'];change=s.chart_maps(nv,pivot,proof);rows=[c.substitute(v,change) for v in rows]
 maps={i:c.substitute(v,change) for i,v in maps.items()};maps.update(change)
 if node['status']!='split':break
 assert len(node['children'])==1
 change=rank.zero_map(c.decode(node['claim']['factors'][0]['linear']),18)
 rows=[c.substitute(v,change) for v in rows]
 maps={i:c.substitute(v,change) for i,v in maps.items()};node=node['children'][0]
relations,_=fast.eliminate(rows,18,[()],progress=False)
search=rank.Search(18,274,pivot,1,0,120)
candidate=[]
for j,r in enumerate(relations):
 f=search.poly(c.decode(r['polynomial']));scalar,fac=f.factor()
 if all(t.total_degree()==1 for t,e in fac):candidate.append((j,str(f),[(str(t),int(e)) for t,e in fac]))
print('relations',len(relations),'factorable',len(candidate),flush=True)
for item in candidate[:15]:print(item,flush=True)
s.shared.save(W/f'rank-leaf-{family}-{pivot}.json.gz',{'family':family,'pivot':pivot,'rows':[c.encode(v) for v in rows],'maps':rank.rb.encode_maps(maps),'relations':relations})
