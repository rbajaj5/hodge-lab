import sys,time,json
from pathlib import Path
from flint import fmpq_mpoly_ctx,fmpq
W=Path(__file__).parent;R=W.parent/'outputs/hodge-lab';sys.path.insert(0,str(R/'algebra'))
import degree7_syzygies as s
import degree7_syzygy_rebuild as rb
c=s.cert
number,pivot=map(int,sys.argv[1:3]); start=time.perf_counter()
packet=rb.read(W/f'rank-seed-{number}-{pivot}.json.gz')
nD=len(packet['system']['basis_indices']);ctx=fmpq_mpoly_ctx.get(tuple('a'+str(i) for i in range(nD)),ordering='degrevlex')
rows={}
for j,enc in enumerate(packet['rows']):
 parts={}
 for mon,q in c.decode(enc).items():
  z=[i for i in mon if i>=nD];assert len(z)<=1
  col=z[0] if z else -1; ex=tuple(mon.count(i) for i in range(nD))
  parts.setdefault(col,{})[ex]=fmpq(q.numerator,q.denominator)
 rows[j]={col:ctx.from_dict(p) for col,p in parts.items()}
steps=[]
def exported():
 return {str(j):{str(col):[[list(map(int,m)),str(q)] for m,q in p.to_dict().items()] for col,p in row.items()} for j,row in rows.items() if row}
def save():
 s.shared.save(W/f'rank-units-{number}-{pivot}.json.gz',{'family':number,'pivot':pivot,'steps':steps,'remaining':exported(),'seconds':time.perf_counter()-start})
while True:
 incid={}
 for j,row in rows.items():
  for col in row:
   if col>=nD:incid.setdefault(col,[]).append(j)
 choices=[]
 for j,row in rows.items():
  for col,p in row.items():
   if col>=nD and p.is_constant():
    choices.append(((len(row)-1)*(len(incid[col])-1),len(row),len(incid[col]),j,col))
 if not choices:break
 *_,j,col=min(choices); prow=rows.pop(j);lead=prow[col].leading_coefficient()
 prow={k:p/lead for k,p in prow.items() if k!=col}
 for k in incid[col]:
  if k==j:continue
  row=rows[k];factor=row.pop(col)
  for z,p in prow.items():
   val=row.get(z,ctx.constant(0))-factor*p
   if val:row[z]=val
   else:row.pop(z,None)
 steps.append([j,col])
 if len(steps)%20==0:
  print(number,pivot,'units',len(steps),'rows',sum(bool(p) for p in rows.values()),'entries',sum(len(p) for p in rows.values()),'seconds',round(time.perf_counter()-start,2),flush=True)
  save()
 if time.perf_counter()-start>90:
  print('bounded stop',flush=True);break
save()
print(number,pivot,'END units',len(steps),'R_rows',sum(any(k>=nD for k in row) for row in rows.values()),'b_rows',sum(set(row)=={-1} for row in rows.values()),'max_degree',max((p.total_degree() for row in rows.values() for p in row.values()),default=0),'seconds',round(time.perf_counter()-start,2),flush=True)
