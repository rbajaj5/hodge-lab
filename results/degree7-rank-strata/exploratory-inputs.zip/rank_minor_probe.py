import sys,time,json
from pathlib import Path
from flint import fmpq_mpoly_ctx,fmpq
W=Path(__file__).parent;R=W.parent/'outputs/hodge-lab';sys.path.insert(0,str(R/'algebra'))
import degree7_syzygies as s
import degree7_syzygy_rebuild as rb
number,pivot=map(int,sys.argv[1:3]);p=rb.read(W/f'rank-units-{number}-{pivot}.json.gz')
ctx=fmpq_mpoly_ctx.get(tuple('a'+str(i) for i in range(18)),ordering='degrevlex')
rows={int(j):{int(k):ctx.from_dict({tuple(m):fmpq(q) for m,q in pol}) for k,pol in row.items()} for j,row in p['remaining'].items()}
groups={}
for j,row in rows.items():
 cols=[k for k in row if k!=-1]
 if len(cols)==1:groups.setdefault(cols[0],[]).append(j)
out=[]
for col,ids in groups.items():
 for m,j in enumerate(ids):
  for k in ids[m+1:]:
   a,b=rows[j],rows[k]
   P=a[col]*b.get(-1,ctx.constant(0))-b[col]*a.get(-1,ctx.constant(0))
   if not P:continue
   scalar,factors=P.factor()
   if all(f.total_degree()==1 for f,e in factors):
    out.append((len(factors),sum(len(f) for f,e in factors),j,k,col,str(P),[(str(f),e) for f,e in factors]))
print('factorable minors',len(out),flush=True)
for item in sorted(out)[:8]: print(item,flush=True)
