import sys,time,json
from pathlib import Path
from flint import fmpq_mpoly_ctx,fmpq
W=Path(__file__).parent;R=W.parent/'outputs/hodge-lab';sys.path.insert(0,str(R/'algebra'))
import degree7_syzygies as s
import degree7_syzygy_rebuild as rb
number,pivot=map(int,sys.argv[1:3]); start=time.perf_counter()
p=rb.read(W/f'rank-units-{number}-{pivot}.json.gz')
ctx=fmpq_mpoly_ctx.get(tuple('a'+str(i) for i in range(18)),ordering='degrevlex')
rows={int(j):{int(k):ctx.from_dict({tuple(m):fmpq(q) for m,q in pol}) for k,pol in row.items()} for j,row in p['remaining'].items()}
steps=p['steps'];guards=[];removed=[]; deps={j:set() for j in rows}
while True:
 singleton=[(len(next(iter(row.values()))),j,next(iter(row))) for j,row in rows.items() if len(row)==1 and -1 not in row]
 if not singleton:break
 _,j,col=min(singleton);guard=rows[j][col];guard/=guard.leading_coefficient()
 if not any(guard==g for g in guards):guards.append(guard)
 dep=deps[j]|{str(guard)}
 removed.append({'row':j,'column':col,'guard':str(guard),'dependencies':sorted(dep)})
 for k,row in rows.items():
  if col in row: deps[k]|=dep; row.pop(col)
necessary=[row[-1] for row in rows.values() if set(row)=={-1}]
active=sorted({col for row in rows.values() for col in row if col!=-1})
out={'family':number,'pivot':pivot,'guards':[str(g) for g in guards], 'removed':removed,
     'remaining_corrections':active,'necessary':[str(g) for g in necessary]}
(W/f'rank-singletons-{number}-{pivot}.json').write_text(json.dumps(out,indent=2))
print('removed',len(removed),'guards',[str(g) for g in guards],'remaining',len(active),'necessary',len(necessary),flush=True)
print([(j,str(row[-1].factor()),sorted(deps[j])) for j,row in rows.items() if set(row)=={-1} and len(row[-1].factor()[1])==1],flush=True)
