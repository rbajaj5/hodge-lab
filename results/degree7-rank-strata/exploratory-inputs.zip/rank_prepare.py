import sys,json,time
from pathlib import Path
W=Path(__file__).parent; R=W.parent/'outputs/hodge-lab'
sys.path.insert(0,str(R/'algebra'))
import degree7_syzygies as s
import degree7_syzygy_rebuild as rb
import syzygy_accelerated as fast
import check_family16_global_cubes as cubes
c=s.cert
c.reduce_span=fast.reduce_span
model=s.triples.Model()
for number in [16,137]:
 family=s.shared.read_packet()['families'][number-1]
 s.triples.verify_family(model,family)
 desc,original=s.shared.construct(model,family)
 nD=len(desc['basis_indices']);nv=nD+len(desc['Koszul_indices'])
 zeros={1:{},9:{}} if number==16 else {}
 if number==16:
  source=json.loads(cubes.PATH.read_text());assert source['system']==desc
  cubes.verify(original,source['claims'])
 reduced=[c.substitute(p,zeros) for p in original]
 for pivot in desc['pivots']:
  start=time.perf_counter()
  proof=c.prove_chart(reduced,nv,pivot)
  c.verify_chart(reduced,nv,proof)
  maps=s.chart_maps(nv,pivot,proof)
  rows=[c.substitute(p,maps) for p in reduced]
  ds=sorted({i for p in rows for mon in p for i in mon if i<nD})
  zs=sorted({i for p in rows for mon in p for i in mon if i>=nD})
  packet={'family':number,'pivot':pivot,'system':desc,'global_zeros':list(zeros),
          'physical_chart':proof,'maps':rb.encode_maps(maps),'rows':[c.encode(p) for p in rows]}
  s.shared.save(W/f'rank-seed-{number}-{pivot}.json.gz',packet)
  print(number,pivot,'closed',proof['excluded'],'D',len(ds),'Z',len(zs),
   'rows',sum(bool(p) for p in rows),'terms',sum(len(p) for p in rows),
   'inferences',sum(len(st['inferences']) for st in proof['stages']),
   'seconds',round(time.perf_counter()-start,2),flush=True)
