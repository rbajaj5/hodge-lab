from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,subprocess,sys,time
R=Path(__file__).resolve().parents[1]/'outputs/hodge-lab'
OUT=R/'results/degree7-rank-strata';OUT.mkdir(exist_ok=True)
def one(case):
 n,p=case;dest=OUT/f'chart-{n}-{p}.json.gz';log=OUT/f'chart-{n}-{p}.log'
 start=time.perf_counter()
 with log.open('w',encoding='utf-8') as f:
  try:
   result=subprocess.run([sys.executable,str(R/'algebra/degree7_rank_strata.py'),'--family',str(n),'--pivot',str(p),'--output',str(dest),'--seconds','120','--nodes','30','--depth','2'],stdout=f,stderr=subprocess.STDOUT,timeout=180)
   status='completed' if result.returncode==0 else 'error';code=result.returncode
  except subprocess.TimeoutExpired:
   status='timeout';code=None
 entry={'family':n,'pivot':p,'status':status,'returncode':code,'seconds':time.perf_counter()-start,'hard_timeout':180,'packet_exists':dest.exists()}
 print(entry,flush=True);return entry
cases=[(16,p) for p in [7,10,11,12,13]]+[(137,p) for p in [8,11,13,16,17]]
with ThreadPoolExecutor(max_workers=2) as pool:result=list(pool.map(one,cases))
(OUT/'attempts.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
