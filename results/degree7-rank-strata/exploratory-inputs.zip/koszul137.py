import sys,json,time,subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
W=Path(__file__).parent;R=W.parent/'outputs/hodge-lab';sys.path.insert(0,str(R/'algebra'))
import degree7_rank_strata as rank
import degree7_koszul_continuation as kc
import syzygy_accelerated as fast
s=rank.s;c=rank.c;OUT=rank.OUT
def worker(p):
 start=time.perf_counter();model=s.triples.Model();kc.verify_global137(model)
 desc,rows,_=rank.seed(model,137,p)
 glob=json.loads((OUT/'global-linear-identities.json').read_text())[1]
 initial={1:{},9:{},**rank.zero_map(c.decode(glob['linear']),18)}
 rows=[c.substitute(v,initial) for v in rows];c.reduce_span=fast.reduce_span
 proof=c.prove_chart(rows,274,p);c.verify_chart(rows,274,proof)
 maps=s.chart_maps(274,p,proof);rows=[c.substitute(v,maps) for v in rows]
 data={'family':137,'pivot':p,'system':desc,'initial_changes':rank.rb.encode_maps(initial),
       'affine_chart':proof,'rows':[c.encode(v) for v in rows]}
 output=W/f'koszul137-{p}.json.gz';s.shared.save(output,data)
 print('initial',p,'excluded',proof['excluded'],flush=True)
 if proof['excluded']:return
 variables=sorted({i for row in rows for m in row for i in m if i<18});mons=[()]+[(i,) for i in variables]
 data['variables']=variables
 def checkpoint(rel,rr,count):
  data.update(relations=rel,expanded_rank=rr,multipliers_processed=count,complete_multiplier_space=count==len(mons),seconds=time.perf_counter()-start)
  s.shared.save(output,data)
 rel,rr=fast.eliminate(rows,18,mons,checkpoint=checkpoint);checkpoint(rel,rr,len(mons))
 data['baseline'],_=fast.eliminate(rows,18,[()],progress=False)
 _,data['selected_new'],_=s.select_new(data['baseline'],rel,variables)
 s.shared.save(output,data)
 pr=c.prove_chart([c.decode(v['polynomial']) for v in data['baseline']]+[c.decode(rel[j]['polynomial']) for j in data['selected_new']],18,p)
 if pr['excluded']:data['denominator_contradiction']=pr
 else:
  data['continuation']=s.continue_search(rows,data,max_degree=4);s.verify_continuation(rows,data)
 s.shared.save(output,data)
 print('finished',p,'excluded',pr['excluded'] or data.get('continuation',{}).get('excluded',False),flush=True)
def run(p):
 start=time.perf_counter();log=W/f'koszul137-{p}.log'
 with log.open('w',encoding='utf-8') as f:
  try:
   cp=subprocess.run([sys.executable,__file__,'worker',str(p)],stdout=f,stderr=subprocess.STDOUT,timeout=150)
   status='completed' if cp.returncode==0 else 'error';code=cp.returncode
  except subprocess.TimeoutExpired:status='timeout';code=None
 result={'family':137,'pivot':p,'status':status,'returncode':code,'seconds':time.perf_counter()-start,'timeout_seconds':150,'log':log.read_text()}
 print(p,status,flush=True);return result
if len(sys.argv)>1:worker(int(sys.argv[2]))
else:
 with ThreadPoolExecutor(max_workers=2) as pool:out=list(pool.map(run,[13,8]))
 (OUT/'family137-attempts.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
