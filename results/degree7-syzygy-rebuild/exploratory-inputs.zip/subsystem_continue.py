import sys,json,gzip,time
from pathlib import Path
from itertools import combinations_with_replacement
from analyze_fast import reduce_span,s,c
W=Path(__file__).parent
data=json.loads((W/'rebuilt-subsystem-115-0.json').read_text())
rows=[c.decode(r['polynomial']) for r in data['relations']]
L={(11,):s.triples.Q(1),(13,):s.triples.Q(1),(14,):s.triples.Q(1),(7,):s.triples.Q(3),(8,):s.triples.Q(-6)}
w,_,_=reduce_span(rows);square=w(c.product(L,L));assert square
maps={7:{(11,):s.triples.Q(-1,3),(13,):s.triples.Q(-1,3),(14,):s.triples.Q(-1,3),(8,):s.triples.Q(2)}}
out={'linear_square':square,'linear_form':c.encode(L),'maps':{str(i):c.encode(p) for i,p in maps.items()},'stages':[],'attempts':[]}
for iteration in range(7):
 current=[c.substitute(p,maps) for p in rows]
 active=sorted({i for p in current for m in p for i in m});found=[]
 for degree in [3,4,5,6]:
  start=time.perf_counter();expanded=[];labels=[]
  for j,p in enumerate(current):
   if not p:continue
   for size in range(degree-max(map(len,p))+1):
    for mon in combinations_with_replacement(active,size):expanded.append(c.product(p,{mon:s.triples.Q(1)}));labels.append((j,mon))
  print('start',iteration,degree,len(expanded),active,flush=True)
  witness,_,rank=reduce_span(expanded)
  def terms(w):return [[labels[j][0],list(labels[j][1]),q] for j,q in w['equation_weights']]
  unit=witness({():s.triples.Q(1)})
  if unit:found=[{'constant':True,'products':terms(unit)}]
  else:
   for i in active:
    for k in range(1,degree+1):
     w=witness({(i,)*k:s.triples.Q(1)})
     if w:found.append({'coordinate':i,'power':k,'products':terms(w)});break
  out['attempts'].append({'iteration':iteration,'degree':degree,'rows':len(expanded),'rank':rank,'seconds':time.perf_counter()-start})
  print('found',[(r.get('coordinate'),r.get('power'),r.get('constant')) for r in found],time.perf_counter()-start,flush=True)
  if found:out['stages'].append({'degree':degree,'claims':found});break
 (W/'subsystem-continuation.json').write_text(json.dumps(out,separators=(',',':')))
 if not found or unit:break
 for r in found:maps[r['coordinate']]={}
 maps={i:c.substitute(p,{r['coordinate']:{} for r in found}) for i,p in maps.items()}
