import sys,gzip,json,subprocess,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'outputs/hodge-lab/algebra'))
import degree7_syzygies as s
c=s.cert;W=Path(__file__).parent
family,pivot=map(int,sys.argv[1:3])
with gzip.open(W/f'rebuild-{family}-{pivot}-0.json.gz','rt') as f:p=json.load(f)
rows=[c.decode(r['polynomial']) for r in p['baseline']]+[c.decode(p['relations'][j]['polynomial']) for j in p['selected_new']]
span=s.triples.base.Elimination()
for j,row in enumerate(rows):span.insert({(0 if any(i in [1,3,4,5,6] for i in m) else 1,m):q for m,q in row.items()},{j:s.triples.Q(1)})
reduced=[{'polynomial':c.encode({m:q for (_,m),q in row.items()}),'weights':[[j,str(q)] for j,q in sorted(track.items())]} for k,(row,track) in sorted(span.basis.items()) if k[0]==1]
variables=sorted({i for r in reduced for m,q in r['polynomial'] for i in m})
stem=W/f'rebuilt-subsystem-{family}-{pivot}'
stem.with_suffix('.json').write_text(json.dumps({'family':family,'pivot':pivot,'variables':variables,'relations':reduced},separators=(',',':')))
def expr(p):return '+'.join('('+str(q)+')'+''.join('*a'+str(i) for i in m) for m,q in p.items()) or '0'
src='ring r=0,('+','.join('a'+str(i) for i in variables)+'),dp;\noption(redSB);\nideal I='+','.join(expr(c.decode(r['polynomial'])) for r in reduced)+';\n'
src+='ideal G=std(I);print("BASIS");G;print("DIM");dim(G);quit;\n'
source=stem.with_suffix('.sing');source.write_text(src)
win=str(source.resolve()).replace('\\','/');linux='/mnt/'+win[0].lower()+win[2:]
start=time.perf_counter();r=subprocess.run(['wsl','-d','Ubuntu','--','timeout','60','Singular','-q',linux],text=True,capture_output=True)
stem.with_suffix('.log').write_text(r.stdout+r.stderr)
stem.with_suffix('.attempt.json').write_text(json.dumps({'returncode':r.returncode,'seconds':time.perf_counter()-start,'timeout_seconds':60},indent=2))
print('subsystem',family,pivot,len(reduced),variables,r.returncode,r.stdout[:1500],flush=True)
