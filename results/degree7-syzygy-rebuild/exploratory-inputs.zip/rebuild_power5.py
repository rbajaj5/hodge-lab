import sys,json,gzip,time
from pathlib import Path
from analyze_fast import reduce_span,s,c
family,pivot=map(int,sys.argv[1:3]);W=Path(__file__).parent
with gzip.open(W/f'rebuild-{family}-{pivot}-0.json.gz','rt') as f:p=json.load(f)
_,rows,_=s.construct(s.triples.Model(),family,pivot)
maps={int(i):c.decode(q) for i,q in p['maps'].items()}
rows=[c.substitute(q,maps) for q in rows]
c.reduce_span=reduce_span
start=time.perf_counter();p['continuation']=s.continue_search(rows,p,max_degree=5)
s.verify_continuation(rows,p)
with gzip.open(W/f'rebuild-power5-{family}-{pivot}.json.gz','wt') as f:json.dump(p,f,separators=(',',':'))
print('done',family,pivot,'excluded',p['continuation']['excluded'],'powers',[[[r.get('coordinate'),r.get('power')] for r in st['claims']] for st in p['continuation']['power_stages']],'attempts',p['continuation']['attempts'],'seconds',time.perf_counter()-start,flush=True)
