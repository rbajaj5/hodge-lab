import sys, json, gzip, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1] / 'outputs/hodge-lab'
sys.path.insert(0, str(ROOT / 'algebra'))
import degree7_syzygies as s
c=s.cert
number,pivot=map(int,sys.argv[1:3])
start=time.perf_counter()
desc,rows,variables=s.construct(s.triples.Model(),number,pivot)
nD=len(desc['basis_indices'])
maps={i:({():s.triples.Q(1)} if i==pivot else {(i,):s.triples.Q(1)}) for i in range(nD)}
if number==115:
    with gzip.open(s.OUT/f'chart-{number}-{pivot}.json.gz','rt') as f: old=json.load(f)
    s.verify_continuation(rows,old)
    maps=s.chart_maps(nD,pivot,old['continuation']['denominator_chart'])
    for stage in old['continuation']['power_stages']:
        changes={r['coordinate']:{} for r in stage['claims']}
        maps={i:c.substitute(p,changes) for i,p in maps.items()}
for iteration in range(4):
    current=[c.substitute(p,maps) for p in rows]
    variables=sorted({i for p in current for m in p for i in m if i<nD})
    print('start',number,pivot,iteration,'freeD',variables,'terms',sum(map(len,current)),flush=True)
    baseline,rank=s.necessary_relations(current,nD,[()])
    print('baseline',len(baseline),'rank',rank,'seconds',time.perf_counter()-start,flush=True)
    # First consume any cheap denominator-only square or affine reductions.
    proof=c.prove_chart([c.decode(r['polynomial']) for r in baseline],nD,pivot)
    changes=s.chart_maps(nD,pivot,proof)
    changed={i:c.substitute(p,changes) for i,p in maps.items()}
    if changed!=maps:
        maps=changed
        print('baseline changes',proof,flush=True)
        continue
    relations,expanded=s.necessary_relations(current,nD,[()]+[(i,) for i in variables])
    br,new,total=s.select_new(baseline,relations,variables)
    print('syzygies',len(relations),'new',len(new),'rank',expanded,'seconds',time.perf_counter()-start,flush=True)
    packet={'family':number,'pivot':pivot,'system':desc,'variables':variables,
      'maps':{str(i):c.encode(p) for i,p in maps.items()},'baseline':baseline,
      'relations':relations,'selected_new':new,'baseline_rank':rank,'expanded_rank':expanded}
    packet['continuation']=s.continue_search(current,packet)
    s.verify_continuation(current,packet)
    path=Path(__file__).resolve().parent/f'rebuild-{number}-{pivot}-{iteration}.json.gz'
    with gzip.open(path,'wt') as f: json.dump(packet,f)
    print('continuation',packet['continuation'],flush=True)
    if packet['continuation']['excluded']: break
    changes=s.chart_maps(nD,pivot,packet['continuation']['denominator_chart'])
    for stage in packet['continuation']['power_stages']:
        changes={i:c.substitute(p,{r['coordinate']:{} for r in stage['claims']}) for i,p in changes.items()}
    changed={i:c.substitute(p,changes) for i,p in maps.items()}
    if changed==maps: break
    maps=changed
print('done',time.perf_counter()-start,flush=True)
