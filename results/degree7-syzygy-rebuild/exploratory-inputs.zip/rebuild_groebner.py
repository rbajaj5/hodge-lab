import sys,gzip,json,subprocess,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'outputs/hodge-lab/algebra'))
import degree7_syzygies as s
c=s.cert
family,pivot=map(int,sys.argv[1:3]);stem=Path(__file__).parent/f'rebuilt-ideal-{family}-{pivot}'
with gzip.open(Path(__file__).parent/f'rebuild-{family}-{pivot}-0.json.gz','rt') as f:p=json.load(f)
rows=[c.decode(r['polynomial']) for r in p['baseline']]+[c.decode(p['relations'][j]['polynomial']) for j in p['selected_new']]
variables=sorted({i for row in rows for m in row for i in m})
def expr(p):
 return '+'.join('('+str(q)+')'+''.join('*a'+str(i) for i in mon) for mon,q in p.items()) or '0'
src='ring r=0,('+','.join('a'+str(i) for i in variables)+'),dp;\noption(redSB);\nideal I='+','.join(expr(p) for p in rows)+';\nideal G=std(I); print("BASIS");G;print("DIM");dim(G);quit;\n'
source=stem.with_suffix('.sing');source.write_text(src)
path=str(source.resolve()).replace('\\','/');path='/mnt/'+path[0].lower()+path[2:]
start=time.perf_counter();r=subprocess.run(['wsl','-d','Ubuntu','--','timeout','90','Singular','-q',path],text=True,capture_output=True)
stem.with_suffix('.log').write_text(r.stdout+r.stderr)
stem.with_suffix('.attempt.json').write_text(json.dumps({'family':family,'pivot':pivot,'timeout_seconds':90,'returncode':r.returncode,'seconds':time.perf_counter()-start},indent=2))
print(family,pivot,r.returncode,r.stdout[:2000],flush=True)
