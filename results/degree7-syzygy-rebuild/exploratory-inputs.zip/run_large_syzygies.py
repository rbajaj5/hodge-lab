import subprocess,sys,time,json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
W=Path(__file__).parent
CASES=[(16,p) for p in [7,10,11,12,13]]+[(137,p) for p in [8,11,13,16,17]]
def one(case):
 f,p=case;log=W/f'fast-{f}-{p}-1.log';start=time.perf_counter()
 with log.open('w') as stream:
  try:
   r=subprocess.run([sys.executable,str(W/'syzygy_fast.py'),str(f),str(p),'1'],stdout=stream,stderr=subprocess.STDOUT,timeout=120)
   status='completed' if r.returncode==0 else 'error';code=r.returncode
  except subprocess.TimeoutExpired:status='timeout';code=None
 result={'family':f,'pivot':p,'multiplier_degree':1,'timeout_seconds':120,'status':status,'returncode':code,'seconds':time.perf_counter()-start,'log':log.read_text()}
 (W/f'fast-{f}-{p}-1.attempt.json').write_text(json.dumps(result,indent=2))
 print(f,p,status,round(result['seconds'],3),flush=True)
 return result
with ThreadPoolExecutor(max_workers=2) as pool:
 results=list(pool.map(one,CASES))
(W/'large-syzygy-attempts.json').write_text(json.dumps(results,indent=2))
