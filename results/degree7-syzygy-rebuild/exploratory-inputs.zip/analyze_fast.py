import sys,json,gzip,time
from pathlib import Path
from flint import fmpq
import syzygy_fast as fast
s=fast.s;c=s.cert

def reduce_span(polynomials):
    monomials=sorted({m for p in polynomials for m in p},key=lambda m:(-len(m),m))
    lookup={m:i for i,m in enumerate(monomials)};span={}
    def add(dst,src,scale):
        for i,e in src.items():
            z=dst.get(i,0)+scale*e
            if z:dst[i]=z
            elif i in dst:del dst[i]
    for j,p in enumerate(polynomials):
        v={lookup[m]:fmpq(q.numerator,q.denominator) for m,q in p.items()};track={j:fmpq(1)}
        while v:
            k=min(v);q=v[k]
            if k not in span:
                span[k]=({i:e/q for i,e in v.items()},{i:e/q for i,e in track.items()});break
            row,comb=span[k];add(v,row,-q);add(track,comb,-q)
    def witness(p):
        if any(m not in lookup for m in p):return None
        v={lookup[m]:fmpq(q.numerator,q.denominator) for m,q in p.items()};track={}
        while v:
            k=min(v);q=v[k]
            if k not in span:return None
            row,comb=span[k];add(v,row,-q);add(track,comb,q)
        return {'polynomial':c.encode(p),'equation_weights':[[j,str(q)] for j,q in sorted(track.items())]}
    linear=[{monomials[k]:s.triples.Q(str(q)) for k,q in row.items()}
            for k,(row,_) in sorted(span.items()) if len(monomials[k])==1]
    return witness,linear,len(span)

if __name__=='__main__':
    family,pivot=map(int,sys.argv[1:3]);W=Path(__file__).parent
    with gzip.open(W/f'fast-{family}-{pivot}-1.json.gz','rt') as f:p=json.load(f)
    _,rows,_=s.construct(s.triples.Model(),family,pivot)
    maps={int(i):c.decode(v) for i,v in p['maps'].items()};rows=[c.substitute(r,maps) for r in rows]
    nD=len(p['system']['basis_indices']);start=time.perf_counter()
    p['baseline'],p['baseline_rank']=fast.eliminate(rows,nD,[()],progress=False)
    br,p['selected_new'],total=s.select_new(p['baseline'],p['relations'],p['variables'])
    p['baseline_multiple_rank']=br
    print('start',family,pivot,'base',len(p['baseline']),'relations',len(p['relations']),'new',len(p['selected_new']),flush=True)
    c.reduce_span=reduce_span
    p['continuation']=s.continue_search(rows,p,max_degree=4)
    s.verify_continuation(rows,p)
    p['analysis_seconds']=time.perf_counter()-start
    with gzip.open(W/f'large-analysis-{family}-{pivot}.json.gz','wt') as f:json.dump(p,f,separators=(',',':'))
    print('done',family,pivot,'excluded',p['continuation']['excluded'],'powers',[[[r.get('coordinate'),r.get('power')] for r in st['claims']] for st in p['continuation']['power_stages']],'attempts',p['continuation']['attempts'],'seconds',p['analysis_seconds'],flush=True)
