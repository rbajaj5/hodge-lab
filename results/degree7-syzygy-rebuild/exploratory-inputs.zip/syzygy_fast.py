"""Discovery accelerator; every exported identity is replayed with Fraction."""
import sys,json,gzip,time
from pathlib import Path
from itertools import combinations_with_replacement
from flint import fmpq
ROOT=Path(__file__).resolve().parents[1]/'outputs/hodge-lab'
sys.path.insert(0,str(ROOT/'algebra'))
import degree7_syzygies as s
c=s.cert

def export(span):
    return [{'polynomial':[[list(m),str(q)] for (_,m),q in sorted(row.items())],
             'products':[[j,list(mon),str(q)] for (j,mon),q in sorted(track.items())]}
            for k,(row,track) in sorted(span.items()) if k[0]==1]

def eliminate(rows,nD,multipliers,progress=True,checkpoint=None):
    span={};start=time.perf_counter()
    converted=[{m:fmpq(v.numerator,v.denominator) for m,v in row.items()} for row in rows]
    def addmul(dst,src,scale):
        for i,e in src.items():
            z=dst.get(i,0)-scale*e
            if z:dst[i]=z
            elif i in dst:del dst[i]
    for mi,mon in enumerate(multipliers):
        for j,row in enumerate(converted):
            v={(0 if any(i>=nD for i in m+mon) else 1,tuple(sorted(m+mon))):q for m,q in row.items()}
            track={(j,mon):fmpq(1)}
            while v:
                k=min(v);coef=v[k]
                if k not in span:
                    span[k]=({i:e/coef for i,e in v.items()},{i:e/coef for i,e in track.items()})
                    break
                other,comb=span[k]
                addmul(v,other,coef);addmul(track,comb,coef)
        if progress and (mi%5==0 or mi==len(multipliers)-1):
            print('multiplier',mi+1,'of',len(multipliers),'rank',len(span),'relations',sum(k[0] for k in span),'seconds',round(time.perf_counter()-start,3),flush=True)
        if checkpoint and (mi%5==0 or mi==len(multipliers)-1):
            checkpoint(export(span),len(span),mi+1)
    return export(span),len(span)

if __name__=='__main__':
    family,pivot,degree=map(int,sys.argv[1:4]);start=time.perf_counter()
    desc,rows,variables=s.construct(s.triples.Model(),family,pivot)
    nD=len(desc['basis_indices']);nv=nD+len(desc['Koszul_indices'])
    if family==115:
        with gzip.open(ROOT/f'results/degree7-syzygies/chart-{family}-{pivot}.json.gz','rt') as f:old=json.load(f)
        s.verify_continuation(rows,old)
        maps=s.chart_maps(nD,pivot,old['continuation']['denominator_chart'])
        for st in old['continuation']['power_stages']:
            maps={i:c.substitute(p,{r['coordinate']:{} for r in st['claims']}) for i,p in maps.items()}
        current=[c.substitute(p,maps) for p in rows]
        # Also remove verified affine numerator dependencies.
        proof=old['continuation']['physical_closure']
        c.verify_chart(current,nv,proof)
        changes=s.chart_maps(nv,pivot,proof)
        maps={i:c.substitute(maps.get(i,{(i,):s.triples.Q(1)}),changes) for i in range(nv)}
    else:
        with gzip.open(s.shared.OUT/f'family-{family}.json.gz','rt') as f:old=json.load(f)
        proof=next(p for p in old['charts'] if p['pivot']==pivot)
        c.verify_chart(rows,nv,proof)
        maps=s.chart_maps(nv,pivot,proof)
    assert all(all(j<nD for m in maps[i] for j in m) for i in range(nD))
    rows=[c.substitute(p,maps) for p in rows]
    variables=sorted({i for p in rows for m in p for i in m if i<nD})
    print('start',family,pivot,degree,'D',variables,'terms',sum(map(len,rows)),flush=True)
    mults=[mon for d in range(degree+1) for mon in combinations_with_replacement(variables,d)]
    out=Path(__file__).parent/f'fast-{family}-{pivot}-{degree}.json.gz'
    def checkpoint(relations,rank,count):
        packet={'family':family,'pivot':pivot,'system':desc,'degree':degree,'maps':{str(i):c.encode(p) for i,p in maps.items()},
                'variables':variables,'relations':relations,'rank':rank,'seconds':time.perf_counter()-start,
                'multipliers_processed':[list(m) for m in mults[:count]],'complete_multiplier_space':count==len(mults)}
        s.shared.save(out,packet)
        return packet
    relations,rank=eliminate(rows,nD,mults,checkpoint=checkpoint)
    packet=checkpoint(relations,rank,len(mults))
    print('DONE',len(relations),'products',sum(len(r['products']) for r in relations),'seconds',packet['seconds'],flush=True)
