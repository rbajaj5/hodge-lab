import sys,subprocess,time,json
from pathlib import Path
family,pivot=map(int,sys.argv[1:3]);stem=Path(__file__).parent/f'rebuilt-ideal-{family}-{pivot}'
source=stem.with_suffix('.sing').read_text().split('ideal G=')[0]
source+='ideal T=1; matrix L=lift(I,T); matrix b=I; matrix P=b*L; print(P==matrix(T));\n'
source+='proc emit(poly p,string tag) { while(p!=0) { print(tag+"|"+string(leadcoef(p))+"|"+string(leadexp(p))); p=p-lead(p); } }\n'
source+='int i; for(i=1;i<=nrows(L);i++) { if(L[i,1]!=0) { emit(L[i,1],"L|"+string(i)); } }\nprint("DONE_EXPORT");quit;\n'
path=stem.with_suffix('.lift.sing');path.write_text(source)
win=str(path.resolve()).replace('\\','/');linux='/mnt/'+win[0].lower()+win[2:]
start=time.perf_counter();r=subprocess.run(['wsl','-d','Ubuntu','--','timeout','120','Singular','-q',linux],text=True,capture_output=True)
stem.with_suffix('.lift.log').write_text(r.stdout+r.stderr)
stem.with_suffix('.lift.attempt.json').write_text(json.dumps({'family':family,'pivot':pivot,'timeout_seconds':120,'returncode':r.returncode,'seconds':time.perf_counter()-start},indent=2))
print(family,pivot,r.returncode,'bytes',len(r.stdout),'done','DONE_EXPORT' in r.stdout,flush=True)
